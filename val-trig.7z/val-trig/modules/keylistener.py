import keyboard

def keylistener_function1(key):
    return keyboard.is_pressed(key)

def keylistener_function2(key):
    # Alternatif bir tuş dinleme yöntemi
    pass