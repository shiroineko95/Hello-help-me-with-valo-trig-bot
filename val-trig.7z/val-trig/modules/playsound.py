import winsound

def beepSound(frequency, duration):
    winsound.Beep(frequency, duration)